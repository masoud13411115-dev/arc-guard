# ARC Guard Android Build Package

سیستم هوشمند گشت امنیتی — Android APK via Capacitor

This package contains everything needed to build the ARC Guard Android apps
(Manager + Guard) from the same React codebase used by the web/PWA version.

---

## What's included

```
ARC_Guard_Android_Project/
├── README.md                       ← You are here
├── ANDROID_BUILD_GUIDE.md          ← Detailed step-by-step guide
├── setup.sh                        ← Automated setup (Linux / macOS)
├── setup.bat                       ← Automated setup (Windows)
├── package.json                    ← npm scripts for all build steps
├── capacitor.manager.config.ts     ← Capacitor config (Manager APK)
├── capacitor.guard.config.ts       ← Capacitor config (Guard APK)
└── android/                        ← Android project scaffold
    ├── build.gradle                ← Root Gradle build
    ├── settings.gradle             ← Module declarations + Capacitor plugins
    ├── variables.gradle            ← Shared SDK versions
    ├── gradle.properties           ← JVM / Gradle settings
    ├── gradlew / gradlew.bat       ← Gradle wrapper launcher
    ├── gradle/wrapper/
    │   └── gradle-wrapper.properties
    └── app/
        ├── build.gradle            ← App build (Manager + Guard flavors)
        ├── proguard-rules.pro
        ├── google-services.json.placeholder   ← Replace with your file!
        └── src/
            ├── main/
            │   ├── AndroidManifest.xml         ← All 8 Android permissions
            │   ├── kotlin/.../MainActivity.kt  ← Capacitor bridge activity
            │   └── res/                        ← Colors, styles, XML configs
            ├── manager/res/values/strings.xml  ← Manager flavor strings
            └── guard/res/values/strings.xml    ← Guard flavor strings
```

---

## APKs produced

| Variant | Package ID | App Name | Target User |
|---------|-----------|----------|-------------|
| **Manager** | `com.arcguard.manager` | ARC Guard Manager | Security managers |
| **Guard** | `com.arcguard.guard` | ARC Guard | Security guards / patrol |

---

## Prerequisites

Install these **on your local machine** (not Replit — Android builds need a full desktop environment):

| Tool | Version | Download |
|------|---------|----------|
| Node.js | 20 LTS or newer | https://nodejs.org |
| JDK | 17 (LTS) | https://adoptium.net |
| Android Studio | Latest | https://developer.android.com/studio |
| Android SDK | API 34 | via Android Studio → SDK Manager |

After installing Android Studio, set `ANDROID_HOME`:

```bash
# macOS / Linux — add to ~/.zshrc or ~/.bashrc
export ANDROID_HOME=$HOME/Library/Android/sdk         # macOS
export ANDROID_HOME=$HOME/Android/Sdk                 # Linux
export PATH=$PATH:$ANDROID_HOME/emulator:$ANDROID_HOME/platform-tools
```

```bat
REM Windows — set in System → Environment Variables
ANDROID_HOME = C:\Users\YourName\AppData\Local\Android\Sdk
```

---

## Quick start

### Step 1 — Unzip and run the setup script

```bash
# Linux / macOS
chmod +x setup.sh
./setup.sh

# Windows
setup.bat
```

The setup script automatically:
- Checks Node.js + Java
- Runs `npm install`
- Runs `npx cap add android` (first time)
- Runs `npx cap sync android`

### Step 2 — Add the web assets

Copy the built React app into `dist/public/`:

**Option A** — Copy from the Replit project after building:
```
# In your Replit workspace terminal:
BASE_PATH=/ PORT=3000 pnpm --filter @workspace/arc-guard run build

# Then download dist/public/ and place it here
```

**Option B** — Build locally (requires the full source):
```bash
BASE_PATH=/ PORT=3000 npm run build:web:manager
```

### Step 3 — Add `google-services.json`  *(required for push notifications)*

1. Open [Firebase Console](https://console.firebase.google.com) → your project
2. **Project Settings → General → Your apps → Add app → Android**
3. Register **two** Android apps:
   - Package: `com.arcguard.manager`
   - Package: `com.arcguard.guard`
4. Download `google-services.json` (it will contain both package IDs)
5. Place it at: `android/app/google-services.json`

> **Security:** Never commit `google-services.json` to git. Add it to `.gitignore`.
> It contains your Firebase project ID but **no private keys**.

### Step 4 — Build the APKs

```bash
# Open Android Studio
npx cap open android

# OR build via command line:

# Manager — debug
cd android && ./gradlew assembleManagerDebug
# Output: android/app/build/outputs/apk/manager/debug/app-manager-debug.apk

# Guard — debug
cd android && ./gradlew assembleGuardDebug
# Output: android/app/build/outputs/apk/guard/debug/app-guard-debug.apk

# Both at once
./gradlew assembleDebug
```

---

## Generating a signed (release) APK

Required for distribution outside of direct USB install.

### 1. Create a keystore (one-time)

```bash
keytool -genkey -v \
  -keystore arc-guard-release.keystore \
  -alias arc-guard \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000
```

> **Keep this file and its passwords safe.** You can never recover a lost keystore.
> Store it outside the project directory (never commit it to git).

### 2. Configure signing in `android/app/build.gradle`

Replace the `signingConfigs` block:

```groovy
signingConfigs {
    release {
        storeFile     file('/path/to/arc-guard-release.keystore')
        storePassword 'your-store-password'
        keyAlias      'arc-guard'
        keyPassword   'your-key-password'
    }
}
buildTypes {
    release {
        signingConfig signingConfigs.release
        minifyEnabled true
        proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
    }
}
```

### 3. Build signed release APK

```bash
cd android && ./gradlew assembleManagerRelease
# Output: android/app/build/outputs/apk/manager/release/app-manager-release.apk
```

### 4. Verify the signature

```bash
apksigner verify --verbose android/app/build/outputs/apk/manager/release/app-manager-release.apk
```

---

## Android permissions included

| Permission | Used for |
|-----------|----------|
| `INTERNET` | Firebase sync, API calls |
| `ACCESS_NETWORK_STATE` | Offline detection |
| `POST_NOTIFICATIONS` | Push alerts (Android 13+) |
| `WAKE_LOCK` | FCM delivery in Doze mode |
| `ACCESS_FINE_LOCATION` | Patrol GPS radius check |
| `ACCESS_COARSE_LOCATION` | GPS fallback |
| `CAMERA` | QR code scanning |
| `VIBRATE` | Alert haptics |

---

## FCM push notifications

Push notifications on Android are handled natively by `@capacitor/push-notifications`
(not the web service worker). The flow:

1. App opens → `initNativePush(companyId, uid)` is called from the Dashboard
2. Android system permission dialog shown (one time)
3. FCM token registered and saved to Firestore: `companies/{companyId}/fcmTokens/{uid}`
4. When manager receives an SOS/missed alert:
   - If app is **open**: `@capacitor/local-notifications` shows a popup
   - If app is **backgrounded/closed**: Android system FCM bridge delivers natively

In-app real-time alerts (via Firestore `subscribeAlerts`) work independently with
no FCM setup — they work offline too via cached data.

---

## Minimum Android version

- **minSdkVersion**: 24 (Android 7.0 Nougat)
- **targetSdkVersion**: 34 (Android 14)
- WebView: Chromium 60+ (auto-updated via Google Play)
- Modern Android (8+) required for notification channels

---

## Troubleshooting

**`ANDROID_HOME` not set / SDK not found**
Set `ANDROID_HOME` and ensure Android SDK Build-Tools 34 is installed via SDK Manager.

**`google-services.json` error during build**
Place the file at `android/app/google-services.json` and re-run `./gradlew assembleDebug`.

**Camera permission denied**
The system permission dialog appears on first QR scan. If denied, guide the user to:
Settings → Apps → ARC Guard → Permissions → Camera → Allow.

**FCM token not generated**
- Check that `google-services.json` contains the correct package ID
- Ensure the Firebase project has Android apps registered for both package IDs
- Check Logcat for `[nativePush]` tag messages

**White flash on startup**
The `AppTheme.NoActionBarLaunch` style sets a dark background during WebView load.
If still flashing, reduce the Vite build's initial chunk size.

**Build fails: `Unable to find method 'com.android.build.api.variant.AndroidComponentsExtension'`**
Update Android Gradle Plugin to 8.3.2 in `android/build.gradle`.

---

## Updating after web code changes

```bash
# 1. Rebuild web assets
BASE_PATH=/ PORT=3000 npm run build:web:manager

# 2. Sync to Android
npx cap sync android

# 3. Rebuild APK in Android Studio (or Gradle)
cd android && ./gradlew assembleManagerDebug
```

---

## Security notes

- `google-services.json` contains your Firebase project ID and sender ID — **not a private key**. Safe to share with team members but do not commit to public repositories.
- The Firebase service account private key (used by a backend) must **never** be included in the APK or client-side code.
- Use Android Keystore for release signing; never commit the `.keystore` file.
- ARC Guard uses Firebase Security Rules to enforce company isolation — no raw database access from the client.
