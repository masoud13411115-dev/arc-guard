# ARC Guard — ProGuard rules for release builds
# Capacitor handles most configuration via its own rules.

# Keep Capacitor bridge classes
-keep class com.getcapacitor.** { *; }
-keep class com.google.firebase.** { *; }

# Keep React/JS entry points
-keep class com.arcguard.** { *; }

# Keep JavaScript interface (Capacitor WebView bridge)
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Firebase Messaging
-keep class com.google.android.gms.** { *; }

# Suppress warnings for Capacitor plugins
-dontwarn com.getcapacitor.**
