package com.arcguard.app

import android.os.Bundle
import com.getcapacitor.BridgeActivity

/**
 * ARC Guard — Main Android Activity
 *
 * Extends Capacitor's BridgeActivity which hosts a WebView that loads
 * the built React web app from dist/public/index.html.
 *
 * All business logic lives in the React/TypeScript layer. This activity
 * is intentionally minimal — Capacitor handles plugin registration,
 * lifecycle bridging, and WebView configuration automatically.
 */
class MainActivity : BridgeActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        // Register Capacitor plugins before super.onCreate
        // (Capacitor auto-discovers plugins annotated with @CapacitorPlugin)
        super.onCreate(savedInstanceState)
    }
}
