import type { CapacitorConfig } from '@capacitor/cli';

/**
 * ARC Guard Guard — Capacitor config
 * appId: com.arcguard.guard
 */
const config: CapacitorConfig = {
  appId:   'com.arcguard.guard',
  appName: 'ARC Guard',
  webDir:  'dist/public',

  plugins: {
    PushNotifications: {
      presentationOptions: ['badge', 'sound', 'alert'],
    },
    LocalNotifications: {
      smallIcon: 'ic_stat_icon_config_sample',
      iconColor: '#22c55e',
    },
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor:    '#0c1829',
      showSpinner:        false,
      splashFullScreen:   true,
      splashImmersive:    true,
    },
  },

  android: {
    buildOptions: { releaseType: 'APK' },
    minWebViewVersion: 60,
  },
};

export default config;
