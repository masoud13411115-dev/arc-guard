import type { CapacitorConfig } from '@capacitor/cli';

/**
 * ARC Guard Manager — Capacitor config
 * appId: com.arcguard.manager
 */
const config: CapacitorConfig = {
  appId:   'com.arcguard.manager',
  appName: 'ARC Guard Manager',
  webDir:  'dist/public',

  plugins: {
    PushNotifications: {
      presentationOptions: ['badge', 'sound', 'alert'],
    },
    LocalNotifications: {
      smallIcon: 'ic_stat_icon_config_sample',
      iconColor: '#0ea5e9',
    },
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor:    '#0c1829',
      showSpinner:        false,
      splashFullScreen:   true,
      splashImmersive:    true,
    },
  },

  android: {
    buildOptions: { releaseType: 'APK' },
    minWebViewVersion: 60,
  },
};

export default config;
