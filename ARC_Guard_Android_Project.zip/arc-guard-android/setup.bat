@echo off
REM ARC Guard Android - Setup Script for Windows
REM Run this once after unzipping the package.

echo ================================================
echo   ARC Guard Android Setup (Windows)
echo ================================================
echo.

REM Check Node.js
node --version >NUL 2>&1
if %ERRORLEVEL% neq 0 (
    echo ERROR: Node.js not found. Install from https://nodejs.org
    pause
    exit /b 1
)
echo [OK] Node.js found

REM Check Java
java -version >NUL 2>&1
if %ERRORLEVEL% neq 0 (
    echo ERROR: Java not found. Install JDK 17 from https://adoptium.net
    pause
    exit /b 1
)
echo [OK] Java found

REM Install dependencies
echo.
echo Installing npm dependencies...
call npm install
echo [OK] Dependencies installed

REM Add Android platform if needed
if not exist "android" (
    echo.
    echo Adding Android platform...
    copy /Y capacitor.manager.config.ts capacitor.config.ts
    call npx cap add android
    echo [OK] Android platform added
) else (
    echo [OK] Android platform already present
)

REM Sync
echo.
echo Syncing Capacitor...
call npx cap sync android
echo [OK] Sync complete

echo.
echo ================================================
echo   REQUIRED: Add google-services.json
echo ================================================
echo.
echo   1. Firebase Console ^> Project Settings ^> Add Android app
echo   2. Register: com.arcguard.manager AND com.arcguard.guard
echo   3. Download google-services.json
echo   4. Place at: android\app\google-services.json
echo.
echo ================================================
echo   Next steps:
echo ================================================
echo   npx cap open android
echo   cd android ^&^& gradlew.bat assembleManagerDebug
echo   cd android ^&^& gradlew.bat assembleGuardDebug
echo.
pause
