#!/bin/bash
# ─────────────────────────────────────────────────────────────────────────────
# ARC Guard Android — Automated Setup Script
# Run this once on your local machine after unzipping the package.
# ─────────────────────────────────────────────────────────────────────────────

set -e
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

echo -e "${GREEN}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║        ARC Guard Android Setup Script            ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════╝${NC}"
echo ""

# ── Prerequisite checks ───────────────────────────────────────────────────────
echo -e "${YELLOW}Checking prerequisites...${NC}"

if ! command -v node &> /dev/null; then
    echo -e "${RED}✗ Node.js not found. Install from https://nodejs.org${NC}"; exit 1
fi
echo -e "${GREEN}✓ Node.js $(node --version)${NC}"

if ! command -v java &> /dev/null; then
    echo -e "${RED}✗ Java not found. Install JDK 17 from https://adoptium.net${NC}"; exit 1
fi
echo -e "${GREEN}✓ Java $(java -version 2>&1 | head -1)${NC}"

if [ -z "$ANDROID_HOME" ]; then
    echo -e "${YELLOW}⚠ ANDROID_HOME not set. Set it to your Android SDK path.${NC}"
    echo "  Example: export ANDROID_HOME=\$HOME/Library/Android/sdk"
fi

# ── Install npm dependencies ───────────────────────────────────────────────────
echo ""
echo -e "${YELLOW}Installing npm dependencies...${NC}"
npm install
echo -e "${GREEN}✓ Dependencies installed${NC}"

# ── Build web assets ───────────────────────────────────────────────────────────
echo ""
echo -e "${YELLOW}Building web assets...${NC}"
echo "  Note: Build requires the full ARC Guard source from the Replit project."
echo "  Copy your built dist/public/ directory here, OR run:"
echo "  BASE_PATH=/ PORT=3000 npx vite build"
echo ""

if [ -d "dist/public" ]; then
    echo -e "${GREEN}✓ dist/public/ found — skipping web build${NC}"
else
    echo -e "${YELLOW}⚠ dist/public/ not found. Attempting to build...${NC}"
    if [ -f "vite.config.ts" ]; then
        BASE_PATH=/ PORT=3000 npx vite build --config vite.config.ts || {
            echo -e "${RED}✗ Web build failed. Copy dist/public/ manually.${NC}"
        }
    fi
fi

# ── Initialize Capacitor ───────────────────────────────────────────────────────
echo ""
echo -e "${YELLOW}Setting up Capacitor...${NC}"

if [ ! -d "android" ]; then
    echo "Adding Android platform..."
    cp capacitor.manager.config.ts capacitor.config.ts
    npx cap add android
    echo -e "${GREEN}✓ Android platform added${NC}"
else
    echo -e "${GREEN}✓ Android platform already exists${NC}"
fi

# ── Apply custom Android files ─────────────────────────────────────────────────
echo ""
echo -e "${YELLOW}Applying custom Android configuration...${NC}"

cp android-overrides/AndroidManifest.xml \
   android/app/src/main/AndroidManifest.xml 2>/dev/null || true

cp android-overrides/build.gradle \
   android/app/build.gradle 2>/dev/null || true

echo -e "${GREEN}✓ Android configuration applied${NC}"

# ── Sync Capacitor ─────────────────────────────────────────────────────────────
echo ""
echo -e "${YELLOW}Syncing Capacitor assets...${NC}"
npx cap sync android
echo -e "${GREEN}✓ Capacitor synced${NC}"

# ── google-services.json reminder ─────────────────────────────────────────────
echo ""
echo -e "${YELLOW}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${YELLOW}║  REQUIRED: Add google-services.json              ║${NC}"
echo -e "${YELLOW}╚══════════════════════════════════════════════════╝${NC}"
echo ""
echo "  1. Open Firebase Console → Project Settings → Add Android app"
echo "  2. Register: com.arcguard.manager  AND  com.arcguard.guard"
echo "  3. Download google-services.json"
echo "  4. Place it at: android/app/google-services.json"
echo ""

# ── Done ───────────────────────────────────────────────────────────────────────
echo -e "${GREEN}╔══════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║  Setup complete!                                 ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════╝${NC}"
echo ""
echo "Next steps:"
echo "  1. Add google-services.json (see above)"
echo "  2. Open Android Studio:  npx cap open android"
echo "  3. Build Manager APK:    cd android && ./gradlew assembleManagerDebug"
echo "  4. Build Guard APK:      cd android && ./gradlew assembleGuardDebug"
echo ""
echo "See README.md for the complete build guide."
