# ARCtime MVP

نسخه اولیه Replit برای:
- QR Check-in
- GPS Validation
- Firebase Firestore
- Manager Dashboard

## راه‌اندازی در Replit

1. در Replit یک پروژه جدید بساز:
   - Template: React یا Vite React
2. فایل‌های این پوشه را داخل پروژه کپی کن.
3. در Shell بزن:
   npm install
   npm run dev

## تنظیم Firebase

1. وارد Firebase Console شو.
2. Create Project بزن.
3. Firestore Database را فعال کن.
4. Web App بساز.
5. مقادیر firebaseConfig را در فایل src/firebase.js جایگزین کن.

## تست QR

برای تست، با هر QR Generator یک QR بساز که متنش این باشد:

ARCTIME|arctime-demo-company|main-branch

بعد در اپ، QR را اسکن کن.

## تنظیم محل شرکت

در فایل src/App.jsx مقدار BRANCH را عوض کن:

lat: عرض جغرافیایی شرکت
lng: طول جغرافیایی شرکت
radiusMeters: شعاع مجاز مثلاً 150 متر
