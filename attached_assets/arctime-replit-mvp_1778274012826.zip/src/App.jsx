import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import { addDoc, collection, getDocs, orderBy, query, serverTimestamp } from "firebase/firestore";
import { Html5QrcodeScanner } from "html5-qrcode";
import { db } from "./firebase";
import "./style.css";

const COMPANY_ID = "arctime-demo-company";
const BRANCH = {
  name: "دفتر مرکزی",
  lat: 35.6892,
  lng: 51.3890,
  radiusMeters: 150
};

// QR دمو: این متن را در QR Code Generator تبدیل به QR کن و روی گوشی تست کن
const VALID_QR_TEXT = "ARCTIME|arctime-demo-company|main-branch";

function distanceMeters(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const toRad = (v) => (v * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function nowText() {
  return new Date().toLocaleString("fa-IR");
}

function App() {
  const [screen, setScreen] = useState("home");
  const [employeeName, setEmployeeName] = useState("علی رضایی");
  const [qrText, setQrText] = useState("");
  const [gps, setGps] = useState(null);
  const [message, setMessage] = useState("");
  const [records, setRecords] = useState([]);
  const scannerRef = useRef(null);

  async function getGps() {
    setMessage("در حال دریافت GPS...");
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error("GPS در این مرورگر پشتیبانی نمی‌شود."));
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const data = {
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
            accuracy: pos.coords.accuracy
          };
          setGps(data);
          setMessage("GPS دریافت شد.");
          resolve(data);
        },
        (err) => {
          reject(new Error("اجازه GPS داده نشد یا موقعیت دریافت نشد."));
        },
        { enableHighAccuracy: true, timeout: 12000, maximumAge: 0 }
      );
    });
  }

  function validateQr(text) {
    return text.trim() === VALID_QR_TEXT;
  }

  async function submitAttendance(type) {
    try {
      setMessage("");
      const location = gps || await getGps();

      const distance = distanceMeters(location.lat, location.lng, BRANCH.lat, BRANCH.lng);
      const gpsOk = distance <= BRANCH.radiusMeters;
      const qrOk = validateQr(qrText);

      if (!qrOk) {
        setMessage("QR معتبر نیست. QR مخصوص شرکت را اسکن کن.");
        return;
      }

      if (!gpsOk) {
        setMessage(`خارج از محدوده شرکت هستی. فاصله تقریبی: ${Math.round(distance)} متر`);
        return;
      }

      await addDoc(collection(db, "attendance"), {
        companyId: COMPANY_ID,
        employeeName,
        type,
        qrText,
        branchName: BRANCH.name,
        gps: location,
        distanceMeters: Math.round(distance),
        createdAt: serverTimestamp(),
        createdAtText: nowText()
      });

      setMessage(type === "check_in" ? "ورود با موفقیت ثبت شد." : "خروج با موفقیت ثبت شد.");
      loadRecords();
    } catch (e) {
      setMessage(e.message || "خطا در ثبت اطلاعات.");
    }
  }

  async function loadRecords() {
    try {
      const q = query(collection(db, "attendance"), orderBy("createdAt", "desc"));
      const snap = await getDocs(q);
      setRecords(snap.docs.map(d => ({ id: d.id, ...d.data() })).slice(0, 20));
    } catch (e) {
      setMessage("برای دیدن گزارش، اول Firebase را درست تنظیم کن.");
    }
  }

  useEffect(() => {
    if (screen === "manager") loadRecords();
  }, [screen]);

  useEffect(() => {
    if (screen !== "scan") return;

    setTimeout(() => {
      const reader = document.getElementById("qr-reader");
      if (!reader || scannerRef.current) return;

      scannerRef.current = new Html5QrcodeScanner(
        "qr-reader",
        { fps: 10, qrbox: 240 },
        false
      );

      scannerRef.current.render(
        (decodedText) => {
          setQrText(decodedText);
          setMessage("QR اسکن شد.");
          scannerRef.current?.clear();
          scannerRef.current = null;
          setScreen("employee");
        },
        () => {}
      );
    }, 300);

    return () => {
      scannerRef.current?.clear().catch(() => {});
      scannerRef.current = null;
    };
  }, [screen]);

  return (
    <div className="app">
      {screen === "home" && (
        <section className="card center">
          <div className="logo">AT</div>
          <h1>ARCtime</h1>
          <p>حضور و غیاب آنلاین با QR + GPS</p>
          <button onClick={() => setScreen("employee")}>ورود کارمند</button>
          <button className="secondary" onClick={() => setScreen("manager")}>پنل مدیر</button>
        </section>
      )}

      {screen === "employee" && (
        <section className="card">
          <div className="top">
            <button className="small" onClick={() => setScreen("home")}>بازگشت</button>
            <span>کارمند</span>
          </div>

          <h2>ثبت حضور</h2>

          <label>نام کارمند</label>
          <input value={employeeName} onChange={(e) => setEmployeeName(e.target.value)} />

          <div className="box">
            <b>QR:</b>
            <p>{qrText || "هنوز QR اسکن نشده"}</p>
          </div>

          <div className="box">
            <b>GPS:</b>
            <p>{gps ? `${gps.lat.toFixed(5)}, ${gps.lng.toFixed(5)} | دقت: ${Math.round(gps.accuracy)}m` : "هنوز GPS دریافت نشده"}</p>
          </div>

          <button onClick={() => setScreen("scan")}>اسکن QR شرکت</button>
          <button className="secondary" onClick={getGps}>دریافت GPS</button>
          <button onClick={() => submitAttendance("check_in")}>ثبت ورود</button>
          <button className="danger" onClick={() => submitAttendance("check_out")}>ثبت خروج</button>

          {message && <div className="message">{message}</div>}

          <div className="hint">
            QR دمو باید این متن را داشته باشد:<br />
            <code>{VALID_QR_TEXT}</code>
          </div>
        </section>
      )}

      {screen === "scan" && (
        <section className="card">
          <div className="top">
            <button className="small" onClick={() => setScreen("employee")}>بازگشت</button>
            <span>QR Scanner</span>
          </div>
          <h2>QR محل شرکت را اسکن کن</h2>
          <div id="qr-reader"></div>
          {message && <div className="message">{message}</div>}
        </section>
      )}

      {screen === "manager" && (
        <section className="card">
          <div className="top">
            <button className="small" onClick={() => setScreen("home")}>بازگشت</button>
            <span>مدیر</span>
          </div>

          <h2>گزارش حضور</h2>
          <button onClick={loadRecords}>بروزرسانی گزارش</button>

          {message && <div className="message">{message}</div>}

          <div className="records">
            {records.length === 0 && <p>هنوز رکوردی ثبت نشده.</p>}
            {records.map(r => (
              <div className="record" key={r.id}>
                <b>{r.employeeName}</b>
                <span>{r.type === "check_in" ? "ورود" : "خروج"}</span>
                <small>{r.createdAtText || "---"}</small>
                <small>فاصله: {r.distanceMeters ?? "--"} متر</small>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
