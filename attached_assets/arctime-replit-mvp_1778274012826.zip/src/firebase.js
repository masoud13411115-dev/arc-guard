import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

/*
  این مقادیر را از Firebase Console بگیر و جایگزین کن:
  Project Settings > General > Your apps > Web app config
*/
const firebaseConfig = {
  apiKey: "PUT_YOUR_API_KEY",
  authDomain: "PUT_YOUR_PROJECT.firebaseapp.com",
  projectId: "PUT_YOUR_PROJECT_ID",
  storageBucket: "PUT_YOUR_PROJECT.appspot.com",
  messagingSenderId: "PUT_YOUR_SENDER_ID",
  appId: "PUT_YOUR_APP_ID"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
